var s = Math.floor(Math.random() * 10) + 1;
var c = Math.floor(Math.random() * 10) + 1;
//eye speed
var ox = 200;
var tx = 270;
var movement = s;
var tmovement = s
//torso speed
var torsoY = 300;
var bodyDirection = s

var hairY = 140;
var hairDirection = c

//glasses
var glassesX = 165;
var glassesY = 200;
var glasses2X = 235;
var glasses2Y = 200;
var glassesDirection = 1
var glasses2Direction = 1

var size = 10;
var head = 150;
var growth = true
let growthAmount = 1;
var count = 0;
var sizeDirection = 2;

function setup() {
  createCanvas(400, 400);
}

function draw()
{
    //background
    background(220,150,0);  
  
    //title
    textSize(40);
    text('Morning Hair', 10, 40);
  
    //hair
  
    triangle(137,260,200,300,263,260)
    rect(125,150,150,100);
    ellipse(200, 150, 150, 100)
    line(115, 255, 285, 205);
    line(115, 205, 285, 255);
    line(115, 235, 285, 175);
    line(115, 175, 285, 235);
    line(115, 215, 285, 155);
    line(115, 155, 285, 215);
  
    //head
    fill(128, 76, 46); 
    rect(175,150,50,200);
    circle(200,200,head);
    if (head >= 200) {
    growth = false
    }
    if (head <= 150) {
    growth = true
    }
  
    if (growth == true) {
    head += growthAmount
    } else {
    head -= growthAmount
    }
 
  
    //torso
    fill(29, 43, 83);
    rect(150,torsoY,100,200);
      torsoY += bodyDirection;
    if(torsoY <= 300 || torsoY >= 350 )
    {
        bodyDirection *= -1;
    }

    //face
    fill(0, 0, 0);
    ellipse(200,hairY,hairY,40);
    hairY += hairDirection;
    if(hairY <= 100 || hairY >= 150 )
    {
        hairDirection *= -1;
    }
    triangle(195,250,200,255,205,250)
    //eyes
    strokeWeight(15);
    circle(ox, 200, 5);
    if (ox >= 200 || ox <= 130) {
    movement *= -1;
    }
    ox += movement;
    circle(tx, 200, 5);
    if (tx >= 270 || tx <= 200) {
    tmovement *= -1;
    }
    tx += tmovement;
    strokeWeight(10);
  
    //glasses
    noFill();
    circle(glassesX,glassesY,65);
    if (glassesX >= 195 || glassesX <= 230); 
    glassesX += glassesDirection;
    if (glassesY >= 230 || glassesY <= 195); 
    glassesY += glassesDirection;
    {
    glassesDirection *= -1;
    }
    glassesDirection += movement;
    strokeWeight(10);
    noFill();
    circle(glasses2X,glasses2Y,65);
    if (glasses2X >= 265 || glasses2X <= 230);
    glasses2X += glasses2Direction;
    if (glasses2Y >= 230 || glasses2Y <= 195); 
    glasses2Y += glasses2Direction;
    {
    glasses2Direction *= -1;
    }
    glasses2Direction += movement;
    strokeWeight(10);
    fill(0);
  
    //signature     
    textSize(size);
    size+= sizeDirection;
    count++;
    if(count > 5)
    {
        sizeDirection *=-1;
        count = 0;
    }
    text('Sebastian Ambriz', 260, 390);
}