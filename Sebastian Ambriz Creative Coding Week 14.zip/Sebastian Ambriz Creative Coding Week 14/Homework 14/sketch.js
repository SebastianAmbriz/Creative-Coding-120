var playerX = 100;
var playerY = 100;

var w = 87; 
var s = 83;
var a = 65;
var d = 68;

var mouseobstacleX = 30;
var mouseobstacleY = 50;


  function setup() 
    {
    createCanvas(560, 480)
      
    bad = new monster(10,160,square,20,82,25,36,10,0);
      
    bad2 = new monster(10,320,square,40,0,97,95,-10,0);
      
    bad3 = new monster(420,10,circle,25,48,48,48,0,10);
      
    bad4 = new monster(140,10,circle,30,136,43,43,0,-10);
    }

  function draw() 
    {
    background (52,79,131)
      
    bad.move();
      
    bad.display();
      
    bad2.move();
      
    bad2.display();
      
    bad3.move();
      
    bad3.display();
      
    bad4.move();
      
    bad4.display();

    createBorders(10);  
    
    createplayer();
    
    playermove(); 

    mouseobstacle(); 
      
    wingame();  
    }


  class monster 
    {
    constructor(x,y,shape,diameter,r,g,b,speedx,speedy) 
    {
    
    this.x = x;
    this.y = y;
    this.shape = shape;
    this.diameter = diameter;
    this.color = color(r,g,b);
    this.speedx = speedx;
    this.speedy = speedy;
    }

    move() 
    {
    this.x += this.speedx;
    this.y += this.speedy;
      
    if(this.x > width)
    {
    this.x = 0;
    }
    if(this.x < 0)
    {
    this.x = width;
    }
    if(this.y > height)
    {
    this.y = 0;
    }
    if(this.y < 0)
    {
    this.y = height;
    }
    }

    display() 
    {
    fill(this.color)
    this.shape(this.x, this.y, this.diameter);
    }
    }

  function createBorders(thickness)
    {
    stroke(0);
    fill(0);
    // top border
    rect(0,0,width,10);
    // left border
    rect(0,0,10,height);
    // bottom border
    rect(0, height-10,width-50, 10);
    // right upper border
    rect(width-10,0,10,height-50);
    textSize(16);
    text("EXIT", width-50,height-50)
    }

  function createplayer()
    {
    fill(255,119,15);
    circle(playerX,playerY,25);
    }

  function mouseobstacle()
    {       
    fill(114,92,127);
    circle(mouseobstacleX, mouseobstacleY, 30); 
    }

  function playermove()
    {
    // handle the keys
    if(keyIsDown(w))
    {
    playerY -= 5;   
    }
    if(keyIsDown(s))
    {
    playerY += 5;   
    }
    if(keyIsDown(a))
    {
    playerX -= 5;   
    }
    if(keyIsDown(d))
    {
    playerX += 5;   
    }
    }


  function mouseobstacle()
    {       
    fill(255,51,153);
    circle(mouseobstacleX, mouseobstacleY, 30); 
    }

  function playermove()
    {
    // handle the keys
    if(keyIsDown(w))
    {
    playerY -= 5;   
    }
    if(keyIsDown(s))
    {
    playerY += 5;   
    }
    if(keyIsDown(a))
    {
    playerX -= 5;   
    }
    if(keyIsDown(d))
    {
    playerX += 5;   
    }
    }

  function mouseClicked()
    {
    mouseobstacleX = mouseX;
    mouseobstacleY = mouseY;
    }
     
   
  function wingame() 
    {
    if(playerX > 550 || playerY > 470)
    {
    fill(0);
    stroke(5);
    textSize(26);
    text("Congrgualtions! You Win!", width/2-50, height/2-50);
    }
    }