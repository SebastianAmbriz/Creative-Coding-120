// x and y for my character
var playerX = 100;
var playerY = 100;
// define the key codes for each letter
var w = 87; 
var s = 83;
var a = 65;
var d = 68;

var boxX = 10;
var boxY = 160;

var boxX2 = 10;
var boxY2 = 320;

var spotX = 10;
var spotY = 320;

var mouseobstacleX = 30;
var mouseobstacleY = 50;

function setup() 
  {
  createCanvas(560, 480)
  }

function draw() 
{
  //enviorment
  background(29, 43, 83)
  stroke(0);
  fill(0);
  // top border
  rect(0,0,width,10);
  // left border
  rect(0,0,10,height);
  // bottom border
  rect(0, height-10,width-50, 10);
  // right upper border
  rect(width-10,0,10,height-50);
  
  textSize(16);
  text("EXIT", width-50,height-50)
  
  //playermovement
  fill(0,153,36);
  circle(playerX,playerY,25);

  // handle the keys
  if(keyIsDown(w))
  {
    playerY -= 5;   
  }
  if(keyIsDown(s))
  {
    playerY += 5;   
  }
  if(keyIsDown(a))
  {
    playerX -= 5;   
  }
  if(keyIsDown(d))
  {
    playerX += 5;   
  }
  if(playerX > 550 && playerY > 470)
  {
  fill(0);
  stroke(5);
  textSize(26);
  text("Congrgualtions! You Win!", width/2-50, height/2-50);
  }
  //enemyobstacles
  fill(230,69,0);

  square(boxX, boxY, 30);  
  square(boxX2, boxY2, 30);
  
  fill(255,51,153);

  circle(440, spotY, 30);

  //speeds
  shapeXSpeed = Math.floor(Math.random() * (Math.floor(Math.random() * 10)) + 1);
  shapeYSpeed = Math.floor(Math.random() * (Math.floor(Math.random() * 10)) + 1);
 
  //enemymovement

  boxX += shapeXSpeed;
  
  //box1boundcheck
  if(boxX > width)
  {
      boxX = 0;
  }
  if(boxX < 0)
  {
      boxX = width;
  }
  if(boxY > height)
  {
      boxY = 0;
  }
  if(boxY < 0)
  {
      boxY = height;
  }
  
  //box2boundcheck
  boxX2 -= shapeXSpeed;
  
  if(boxX2 > width)
  {
      boxX2 = 0;
  }
  if(boxX2 < 0)
  {
      boxX2 = width;
  }
  if(boxY2 > height)
  {
      boxY2 = 0;
  }
  if(boxY2 < 0)
  {
      boxY2 = height;
  }
  
  //spotboundcheck
  spotY -= shapeYSpeed;
  
  if(spotX > width)
  {
      spotX = 0;
  }
  if(spotX < 0)
  {
      spotX = width;
  }
  if(spotY > height)
  {
      spotY = 0;
  }
  if(spotY < 0)
  {
      spotY = height;
  }

  // create the shape based on the mouse click
  fill(114,92,127);
  square(mouseobstacleX, mouseobstacleY, 30);
  } 

function mouseClicked()
  {
  mouseobstacleX = mouseX;
  mouseobstacleY = mouseY;
  }