function setup() {
  createCanvas(400, 400);
}

function draw()
{
    //background
    background(220,150,0);  
  
    //title
    textSize(40);
    text('Morning Hair', 10, 40);
  
    //hair
  
    triangle(137,260,200,300,263,260)
    rect(125,150,150,100);
    ellipse(200, 150, 150, 100)
    line(115, 255, 285, 205);
    line(115, 205, 285, 255);
    line(115, 235, 285, 175);
    line(115, 175, 285, 235);
    line(115, 215, 285, 155);
    line(115, 155, 285, 215);
  
    //head
    fill(128, 76, 46); 
    rect(175,150,50,200);
    circle(200,200,150); 
    fill(29, 43, 83); 
  
    //torso
    rect(150,300,100,200);
    fill(0, 0, 0);
  
    //face
    ellipse(200,140,100,30); 
    triangle(195,250,200,255,205,250)
    strokeWeight(15);
    point(165,200);
    point(235,200);
    strokeWeight(10);
  
    //glasses
    noFill();
    circle(165,200,65);
    noFill();
    circle(235,200,65);
    strokeWeight(10);
    fill(0);
  
    //signature     
    textSize(15);
    text('Sebastian Ambriz', 280, 390);
}