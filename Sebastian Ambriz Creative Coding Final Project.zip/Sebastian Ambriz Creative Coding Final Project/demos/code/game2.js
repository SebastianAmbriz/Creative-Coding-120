
var playerX = 100;
var playerY = 100;

var w = 87; 
var s = 83;
var a = 65;
var d = 68;

var boxX1 = 10;
var boxY1 = 160;

var boxX2 = 10;
var boxY2 = 320;

var spotX = 10;
var spotY = 320;

var mouseobstacleX = 30;
var mouseobstacleY = 50;

shapeXSpeed = Math.floor(Math.random() * (Math.floor(Math.random() * 10)) + 1);
shapeYSpeed = Math.floor(Math.random() * (Math.floor(Math.random() * 10)) + 1);

function setup() 
    {
    createCanvas(560, 480)
    }

  function draw() 
    {
    background(29, 43, 83)
          
    createBorders(10);  
    
    createplayer();
    
    playermove(); 

    mouseobstacle();
      
    drawenemies(boxX1, boxY1); 
      
    drawenemies(boxX2, boxY2);  
    
    moveenemies()
      
    spot()
      
    wingame();  
    }

  function createBorders(thickness)
    {
    stroke(0);
    fill(0);
    // top border
    rect(0,0,width,10);
    // left border
    rect(0,0,10,height);
    // bottom border
    rect(0, height-10,width-50, 10);
    // right upper border
    rect(width-10,0,10,height-50);
    textSize(16);
    text("EXIT", width-50,height-50)
    }

  function createplayer()
    {
    fill(0,153,36);
    circle(playerX,playerY,25);
    }

  function mouseobstacle()
    {       
    fill(114,92,127);
    circle(mouseobstacleX, mouseobstacleY, 30); 
    }

  function playermove()
    {
    // handle the keys
    if(keyIsDown(w))
    {
    playerY -= 5;   
    }
    if(keyIsDown(s))
    {
    playerY += 5;   
    }
    if(keyIsDown(a))
    {
    playerX -= 5;   
    }
    if(keyIsDown(d))
    {
    playerX += 5;   
    }
    }

  function drawenemies(boxX, boxY)
    {
    fill(230,69,0);

    square(boxX, boxY, 30);  
  
    fill(255,51,153);

    circle(440, spotY, 30);  
    }


  function moveenemies()
    {
    boxX1 += shapeXSpeed;
  
    if(boxX1 > width)
    {
    boxX1 = 0;
    }
    if(boxX1 < 0)
    {
    boxX1 = width;
    }
    if(boxY1 > height)
    {
    boxY1 = 0;
    }
    if(boxY1 < 0)
    {
    boxY1 = height;
    }
      
    boxX2 -= shapeXSpeed;
  
    if(boxX2 > width)
    {
    boxX2 = 0;
    }
    if(boxX2 < 0)
    {
    boxX2 = width;
    }
    if(boxY2 > height)
    {
    boxY2 = 0;
    }
    if(boxY2 < 0)
    {
    boxY2 = height;
    }
    }


  function spot()
    {
    spotY -= shapeYSpeed;
    if(spotX > width)
    {
    spotX = 0;
    }
    if(spotX < 0)
    {
    spotX = width;
    }
    if(spotY > height)
    {
    spotY = 0;
    }
    if(spotY < 0)
    {
    spotY = height;
    }
    }

  function mouseClicked()
    {
    mouseobstacleX = mouseX;
    mouseobstacleY = mouseY;
    }
   
  function wingame() 
    {
    if(playerX > 550 || playerY > 470)
    {
    fill(0);
    stroke(5);
    textSize(26);
    text("Congrgualtions! You Win!", width/2-50, height/2-50);
    }
    }
      
      
      
