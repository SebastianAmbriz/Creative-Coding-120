var playerX = 100;
var playerY = 100;

var w = 87; 
var s = 83;
var a = 65;
var d = 68;

var mouseobstacleX = 30;
var mouseobstacleY = 50;

let bad = []; 
let bad2 = []; 

  function setup() 
    {
    createCanvas(560, 480)
      
    for (let i = 0; i < 5; i++) 
    {
    bad.push(new monster(circle));
    bad2.push(new monster(square));
    }
    }

  function draw() 
    {
    background (52,79,131)
    
    for (let i = 0; i < bad.length; i++) 
    {
    bad[i].move();
    bad[i].display();
    }
      
    for (let i = 0; i < bad2.length; i++) 
    {
    bad2[i].move();
    bad2[i].display();
    }

    createBorders(10);  
    
    createplayer();
    
    playermove(); 

    mouseobstacle(); 
      
    wingame();  
    }


  class monster 
    {
    constructor(shape, r, g, b) 
    {
    r = random(255);
    g = random(255);
    b = random(255);
    this.x = random(width);
    this.y = random(height);
    this.shape = shape;
    this.point = point;
    this.diameter = random(5, 50);
    this.color = color(r,g,b);
    this.speedx = random(-10, 10);
    this.speedy = random(-10, 10);
    }

    move() 
    {
    this.x += this.speedx;
    this.y += this.speedy;
      
    if(this.x > width)
    {
    this.x = 0;
    }
    if(this.x < 0)
    {
    this.x = width;
    }
    if(this.y > height)
    {
    this.y = 0;
    }
    if(this.y < 0)
    {
    this.y = height;
    }
    }

    display() 
    {
    fill(this.color)
    this.shape(this.x, this.y, this.diameter);
    }
    }

  function createBorders(thickness)
    {
    stroke(0);
    fill(0);
    // top border
    rect(0,0,width,10);
    // left border
    rect(0,0,10,height);
    // bottom border
    rect(0, height-10,width-50, 10);
    // right upper border
    rect(width-10,0,10,height-50);
    textSize(16);
    text("EXIT", width-50,height-50)
    }

  function createplayer()
    {
    fill(255,119,15);
    star(playerX,playerY, 10, 25, 9);
    }

  function playermove()
    {
    // handle the keys
    if(keyIsDown(w))
    {
    playerY -= 5;   
    }
    if(keyIsDown(s))
    {
    playerY += 5;   
    }
    if(keyIsDown(a))
    {
    playerX -= 5;   
    }
    if(keyIsDown(d))
    {
    playerX += 5;   
    }
    }

  function mouseobstacle()
    {       
    fill(255,51,153);
    star(mouseobstacleX, mouseobstacleY, 10, 20, 5); 
    }

  function playermove()
    {
    // handle the keys
    if(keyIsDown(w))
    {
    playerY -= 5;   
    }
    if(keyIsDown(s))
    {
    playerY += 5;   
    }
    if(keyIsDown(a))
    {
    playerX -= 5;   
    }
    if(keyIsDown(d))
    {
    playerX += 5;   
    }
    }

  function star(x, y, radius1, radius2, points) 
    {
    let angle = TWO_PI / points;
    let halfAngle = angle / 2.0;
    beginShape();
    for (let a = 0; a < TWO_PI; a += angle) {
    let sx = x + cos(a) * radius2;
    let sy = y + sin(a) * radius2;
    vertex(sx, sy);
    sx = x + cos(a + halfAngle) * radius1;
    sy = y + sin(a + halfAngle) * radius1;
    vertex(sx, sy);
    }
    endShape(CLOSE);
    }

  function mouseClicked()
    {
    mouseobstacleX = mouseX;
    mouseobstacleY = mouseY;
    }
     
   
  function wingame() 
    {
    if(playerX > 550 || playerY > 470)
    {
    fill(0);
    stroke(5);
    textSize(26);
    text("Congrgualtions! You Win!", width/2-50, height/2-50);
    }
    }